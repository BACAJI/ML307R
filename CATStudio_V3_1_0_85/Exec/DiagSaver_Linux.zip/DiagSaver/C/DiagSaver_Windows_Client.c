﻿#include <stdio.h>
#include <winsock2.h>
#include <winsock.h>
#include <windows.h>
#include <io.h>
#include <time.h>
#include <sys/stat.h>
#pragma comment(lib,"ws2_32.lib")
struct CSDLFileHeader
{
    int    dwHeaderVersion;//0x0
    int    dwDataFormat;//0x1
    int    dwAPVersion;
    int    dwCPVersion;
    int    dwSequenceNum;
    int    dwTime;//Total seconds from 1970.1.1 0:0:0
    int    dwCheckSum;//0x0
};

#define FILE_SIZE           200  //200MB
#define MAX_TRANSFER	 	(4096)
#define MAX_FINDDBVER_NUM	10

char g_szLogFileName[256] = {0};
char g_szServerIP[256] = {0};
char g_szDevSerNum[256] = {0};
#define SERVPORT		32768
char ACATReady[16] = {0x10, 0x00, 0x00, 0x00, 0x00, 0x04, 0xFF, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}; // ACAT Ready command
char GetAPDBVer[16]= {0x10, 0x00, 0x00, 0x00, 0x80, 0x00, 0xFF, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}; // Get AP DB Ver command
char GetCPDBVer[16]= {0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0xFF, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}; // Get CP DB Ver command
WSADATA data;

int g_nFindDbVer = 0;
size_t g_uiFileSize = FILE_SIZE;
FILE *g_hFile = NULL;
unsigned int g_uiFileIndex = 0x0;
unsigned int g_ProgIndex = 0;
struct CSDLFileHeader g_SDLHeader;
SOCKET sclient;
int g_nFileMaxCount = 1;
char g_szFileDir[256] = ".\\";
char rbuf[MAX_TRANSFER] = {0};
BOOL CtrlHandler( DWORD fdwCtrlType ) 
{ 
  switch( fdwCtrlType ) 
  { 
    // Handle the CTRL-C signal. 
    case CTRL_C_EVENT: 
      printf( "Ctrl-C event\n\n" );
      if (g_hFile != NULL)
      {
          fclose(g_hFile);
          g_hFile = NULL;
      }
      if (sclient != INVALID_SOCKET)
      {
          closesocket(sclient);
      }
	  WSACleanup();
      exit(0);
 
    // CTRL-CLOSE: confirm that the user wants to exit. 
    case CTRL_CLOSE_EVENT: 
      printf( "Ctrl-Close event\n\n" );
      return( TRUE ); 
 
    // Pass other signals to the next handler. 
    case CTRL_BREAK_EVENT: 
      printf( "Ctrl-Break event\n\n" );
      return FALSE; 
 
    case CTRL_LOGOFF_EVENT: 
      printf( "Ctrl-Logoff event\n\n" );
      return FALSE; 
 
    case CTRL_SHUTDOWN_EVENT: 
      printf( "Ctrl-Shutdown event\n\n" );
      return FALSE; 
 
    default: 
      return FALSE; 
  } 
} 

int FindDBVer(char *pBuff, int nLength)
{
	char *pCurrent = pBuff;
	if (pBuff==NULL)
	{
		return 0;
	}

	//char szAPDBVer[9] = {0};
	//char szCPDBVer[9] = {0};
	

	//printf("pBurr: 0x%X, nLength: %d\n", pBuff, nLength);
	while( (pCurrent+27) <= (pBuff+nLength) )
	{
		if ( (char)0x1B == *pCurrent && (char)0x00 == *(pCurrent+1) && (char)0x00 == *(pCurrent+2) && (char)0x00 == *(pCurrent+3) )
		{
			//printf("Found the PDU Head!\n");
			//printf("\npCurrent+8 == 0xFF: %d!", -1 == *(pCurrent+8));
			//printf("\npCurrent+8: 0x%X!", (char)*(pCurrent+8));
			//printf("\npCurrent+10 == 0x00: %d!", 0x00 == *(pCurrent+10));
			//printf("\npCurrent+10: %d!", *(pCurrent+10));
			if ( (char)0x01 == *(pCurrent+4) && (char)0xFF == *(pCurrent+8) && (char)0xFF == *(pCurrent+9) \
				&& ((char)0x00 == *(pCurrent+10)) && ((char)0x00 == *(pCurrent+11)) )
			{
				//printf("\nFound DB Ver\n");
				if( 0x00 == *(pCurrent+5) )
				{
					//memcpy(szCPDBVer, pCurrent+18, 9);
					g_SDLHeader.dwCPVersion = strtoul(pCurrent+18, NULL, 16);
					printf("\nGot the CP DB Ver: 0x%X\n", g_SDLHeader.dwCPVersion);
					return 1;
				}
				else if ( (char)0x80 == *(pCurrent+5) )
				{
					//memcpy(szAPDBVer, pCurrent+18, 9);
					g_SDLHeader.dwAPVersion = strtoul(pCurrent+18, NULL, 16);
					//printf("\nGot the AP DB Ver: 0x%X\n", g_SDLHeader.dwAPVersion);
				}
				else
				{
					//printf("\npCurrent+5: %d!", *(pCurrent+5));
					printf("\nSAP is invalid\n");
				}

				pCurrent+=15;
			}
			else
			{
				//printf("\npCurrent+11: %d!\n", *(pCurrent+11));
			}
		}

		pCurrent++;
	}
	g_nFindDbVer++;
	//printf("pCurrent: 0x%X\n", pCurrent);
	return 0;
}

int savelog(char *buf, int len)
{
	int i;
	time_t ltime;
	struct tm *currtime;
	struct stat fileinfo;
	char openmode[4] = {0};

	char *pHeader = (char *)&g_SDLHeader;
	char szLogPath[256];
	if (g_szFileDir[strlen(g_szFileDir)-1] == '/')
		g_szFileDir[strlen(g_szFileDir)-1] = 0;
	memcpy(szLogPath, g_szFileDir, sizeof(g_szFileDir));

	if ( 0 == strlen(g_szLogFileName)  )
	{
		time(&ltime);

		g_SDLHeader.dwTime = (long)ltime;
		g_SDLHeader.dwSequenceNum = g_uiFileIndex;// File index, start from 0
		g_uiFileIndex++;
		currtime = localtime(&ltime);
		sprintf(g_szLogFileName, "%s//%d_%d_%d_%d_%d_%d.sdl", szLogPath, (currtime->tm_year+1900), (currtime->tm_mon+1), currtime->tm_mday, currtime->tm_hour, currtime->tm_min, currtime->tm_sec);
		//sprintf(openmode, "wb");
		g_hFile = fopen(g_szLogFileName, "wb");

		printf("Saving the log(%s) to %s\\ folder in current path!\n", g_szLogFileName,szLogPath);
		printf("1++g_SDLHeader.dwTime:0x%x,.dwCPVersion:0x%x,.dwSequenceNum:0x%x\n",g_SDLHeader.dwTime,g_SDLHeader.dwCPVersion,g_SDLHeader.dwSequenceNum);
		// Write the file header.
		if( fwrite(pHeader, 28, 1, g_hFile) != 1 )
		{
			printf("Write Header fail: create file.\n");
		}
		//CleanOldSdl(szLogPath,0);
		//        for(i=0; i<28; i++)
		//            fputc(pHeader[i], g_hFile);
	}
	else
	{
		stat(g_szLogFileName, &fileinfo);
		if( (g_uiFileSize>0 && fileinfo.st_size > g_uiFileSize*1024*1024-len) || (fileinfo.st_size > FILE_SIZE*1024*1024-len) ) 
		{
			// Update the AP CP DB Version before close the file
			g_hFile = fopen(g_szLogFileName, "ab+");
			fseek(g_hFile, 0, SEEK_SET);
			if( fwrite(pHeader, 28, 1, g_hFile) != 1 )
			{
				printf("Write Header fail: file size is not enough.\n");
			}
			//            for(i=0; i<28; i++)
			//                fputc(pHeader[i], g_hFile);

			fclose(g_hFile);
			g_hFile = NULL;


			time(&ltime);

			g_SDLHeader.dwTime = (long)ltime;
			g_SDLHeader.dwSequenceNum = g_uiFileIndex;
			g_uiFileIndex++;    // Increse the file index
			currtime = localtime(&ltime);
			sprintf(g_szLogFileName, "%s//%d_%d_%d_%d_%d_%d.sdl", szLogPath, currtime->tm_year+1900, currtime->tm_mon+1, currtime->tm_mday, currtime->tm_hour, currtime->tm_min, currtime->tm_sec);
			//          sprintf(openmode, "wb");
			g_hFile = fopen(g_szLogFileName, "wb");
			// Write the file header.
			if( fwrite(pHeader, 28, 1, g_hFile) != 1 )
			{
				printf("Write Header fail: create a new file.\n");
			}
			printf("++created new log file(%s)\n",g_szLogFileName);
			//            for(i=0; i<28; i++)
			//                fputc(pHeader[i], g_hFile);

			//CleanOldSdl(szLogPath,0);
		}
		else
		{
			//sprintf(openmode, "ab+");
			g_hFile = fopen(g_szLogFileName, "ab+");
		}
	}

	// Write the data to current file.
	if( fwrite(buf, len, 1, g_hFile) != 1 )
	{
		printf("Write data fail.\n");
	}
	//    for(i=0; i<len; i++)
	//        fputc(buf[i], g_hFile);

	if(g_hFile != NULL)
	{
		fclose(g_hFile);
		g_hFile = NULL;
	}
	return 1;

}

int main(int argc, char *argv[])
{
    WORD sockVersion = MAKEWORD(2,2);
    int flag_findDB = 0;
    struct sockaddr_in serAddr;
	int rc;
    if(WSAStartup(sockVersion, &data) != 0)
    {
        return 0;
    }

    sclient = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if(sclient == INVALID_SOCKET)
    {
        printf("invalid socket !");
        return 0;
    }
     if( !SetConsoleCtrlHandler( (PHANDLER_ROUTINE) CtrlHandler, TRUE ) ) 
    {
        printf( "\nERROR: Could not set control handler"); 
        return 1;
    }

            // init the SDL file header
    g_SDLHeader.dwHeaderVersion = 0;
    g_SDLHeader.dwDataFormat = 1;//0x1
    g_SDLHeader.dwAPVersion = 0;//strtol(g_szAPDBVer, NULL, 16);
    g_SDLHeader.dwCPVersion = 0;//strtol(g_szCPDBVer, NULL, 16);
    g_SDLHeader.dwTime = 0;//Total seconds from 1970.1.1 0:0:0
    g_SDLHeader.dwCheckSum = 0;//0x0
    while (1)
    {
        printf("Please input server ip:\n");
        scanf("%s",g_szServerIP);
        serAddr.sin_family = AF_INET;
        serAddr.sin_port = htons(SERVPORT);
        serAddr.sin_addr.S_un.S_addr = inet_addr(g_szServerIP);
        if (connect(sclient, (struct sockaddr *)&serAddr, sizeof(serAddr)) == SOCKET_ERROR)
        {
            printf("connect error !\n");
            closesocket(sclient);
            continue;
        }
		break;
    }
/*
	printf("Please enter Max sdl file count[Example: 20]: \n");
	scanf("%d", &g_nFileMaxCount);
	printf("========================================================\n");*/
	while (1)
	{
		printf("Please enter the Dir of Log Files[Example: ./]: \n");
		scanf("%s", g_szFileDir);
		CreateDirectory(g_szFileDir,NULL);
		if (access(g_szFileDir,0) == 0)
			break;
	}
	printf("========================================================\n");
	while (1)
	{
		printf("Please enter the Log File Size MB, Not Bigger than %dM or Input 0 to Create a new Log File when UE reboot[Example: 20]: \n",FILE_SIZE);
		scanf("%u", &g_uiFileSize);
		if (g_uiFileSize <= FILE_SIZE)
			break;
	}


    send(sclient, ACATReady, strlen(ACATReady), 16);
	send(sclient, GetAPDBVer, strlen(ACATReady), 16);
	send(sclient, GetCPDBVer, strlen(ACATReady), 16);
	printf("Sent CMD, receiving data. Press Ctrl+C to exit.\n");
    while (1)
	{
		rc = recv(sclient, rbuf, MAX_TRANSFER, 0);
		if(rc > 0)
		{
			savelog(rbuf,rc);
			if (g_nFindDbVer < MAX_FINDDBVER_NUM && flag_findDB ==0)
				flag_findDB = FindDBVer(rbuf,rc);
		}
	}
    closesocket(sclient);
    WSACleanup();
    return 0;
}