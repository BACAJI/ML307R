/*
* DiagSaver application
*
* Marvell Diag log saver on Linux - 2.0.0.0
*
* Copyright (C) 1995-2015 Marvell.Co.,LTD
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <termios.h>
#include <time.h>
#include <signal.h>
#include <dirent.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <sys/types.h>
#include "BulkDevNonDrv_Linux.h"

struct CSDLFileHeader
{
    int    dwHeaderVersion;//0x0
    int    dwDataFormat;//0x1
    int    dwAPVersion;
    int    dwCPVersion;
    int    dwSequenceNum;//�ļ���ţ���0��ʼ����
    int    dwTime;//Total seconds from 1970.1.1 0:0:0
    int    dwCheckSum;//0x0
};

#define FILE_SIZE           200  //200MB
#define MAX_TRANSFER        0x2000
#define MAX_FINDDBVER_NUM	10

char g_szLogFileName[256] = {0};
char g_szDevName[256] = {0};
char g_szDevSerNum[256] = {0};
char g_szFileDir[256] = "./";
PUSB_HANDLE g_pSelectedUSB = NULL;
int g_ttyfd = -1;
int g_hDevHandle = 0;
int g_nReadFailCount = 0;
int g_nFileMaxCount = 1;
int g_isTty = 0;
int g_nFindDbVer = 0;
size_t g_uiFileSize = FILE_SIZE;
FILE *g_hFile = NULL;
unsigned int g_uiFileIndex = 0x0;
unsigned int g_ProgIndex = 0;
struct CSDLFileHeader g_SDLHeader;




unsigned char ACATReady[16] = {0x10, 0x00, 0x00, 0x00, 0x00, 0x04, 0xFF, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}; // ACAT Ready command
unsigned char GetAPDBVer[16]= {0x10, 0x00, 0x00, 0x00, 0x80, 0x00, 0xFF, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}; // Get AP DB Ver command
unsigned char GetCPDBVer[16]= {0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0xFF, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}; // Get CP DB Ver command


static int is_ttydevice(const char *dev) {
    return !strncmp(dev, "/dev/tty", strlen("/dev/tty"));
}

int openport(char *pszDeviceName)
{
    int tmpfd = open( pszDeviceName, O_RDWR|O_SYNC|O_NOCTTY|O_NDELAY );
    if (-1 == tmpfd)
    {
        printf("Can't Open Diag device!  %s\n",pszDeviceName);
        return -1;
    }
    else
    {
        printf ("\nOpened Diag DeviceName : %s\n",pszDeviceName);
        return tmpfd;
    }
}

int set_tty_port(int fd, int baud,int databits,int stopbits,int parity)
{
    int baudrate;
    struct   termios   newtio;
    switch(baud)
    {
    case 300:
        baudrate=B300;
        break;
    case 600:
        baudrate=B600;
        break;
    case 1200:
        baudrate=B1200;
        break;
    case 2400:
        baudrate=B2400;
        break;
    case 4800:
        baudrate=B4800;
        break;
    case 9600:
        baudrate=B9600;
        break;
    case 19200:
        baudrate=B19200;
        break;
    case 38400:
        baudrate=B38400;
        break;
    default :
        baudrate=B9600;
        break;
    }
    tcgetattr(fd,&newtio);
    bzero(&newtio,sizeof(newtio));
    //setting   c_cflag
    newtio.c_cflag   &=~CSIZE;
    switch (databits)
    {
    case 7:
        newtio.c_cflag |= CS7;
        break;
    case 8:
        newtio.c_cflag |= CS8;
        break;
    default:
        newtio.c_cflag |= CS8;
        break;
    }
    switch (parity) //����У��
    {
    case 'n':
    case 'N':
        newtio.c_cflag &= ~PARENB;   /* Clear parity enable */
        newtio.c_iflag &= ~INPCK;     /* Enable parity checking */
        break;
    case 'o':
    case 'O':
        newtio.c_cflag |= (PARODD | PARENB);
        newtio.c_iflag |= INPCK;             /* Disnable parity checking */
        break;
    case 'e':
    case 'E':
        newtio.c_cflag |= PARENB;     /* Enable parity */
        newtio.c_cflag &= ~PARODD;
        newtio.c_iflag |= INPCK;       /* Disnable parity checking */
        break;
    case 'S':
    case 's':  /*as no parity*/
        newtio.c_cflag &= ~PARENB;
        newtio.c_cflag &= ~CSTOPB;
        break;
    default:
        newtio.c_cflag &= ~PARENB;   /* Clear parity enable */
        newtio.c_iflag &= ~INPCK;     /* Enable parity checking */
        break;
    }
    switch (stopbits)//����ֹͣλ
    {
    case 1:
        newtio.c_cflag &= ~CSTOPB;  //1
        break;
    case 2:
        newtio.c_cflag |= CSTOPB;  //2
        break;
    default:
        newtio.c_cflag &= ~CSTOPB;
        break;
    }
    newtio.c_cc[VTIME] = 0;
    newtio.c_cc[VMIN] = 0;
    newtio.c_cflag   |=   (CLOCAL|CREAD);
    //newtio.c_oflag|=OPOST;
    newtio.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG); //Input, RawData mode
    newtio.c_oflag &= ~OPOST; //Output
    newtio.c_iflag   &=~(IXON|IXOFF|IXANY);
    cfsetispeed(&newtio,baudrate);
    cfsetospeed(&newtio,baudrate);
    tcflush(fd,   TCIFLUSH);
    if (tcsetattr(fd,TCSANOW,&newtio) != 0)
    {
        perror("SetupSerial 3\n");
        return -1;
    }
    return 0;
}

int writeport(PUSB_HANDLE pUSB,unsigned char *buf,int len)
{
    int i;
	if (!g_isTty)
	{
	    if( NULL == pUSB )
	    {
	        return -1;
	    }

	    DiagDev_Write(pUSB,buf,len);
	} else
	{
		write(g_ttyfd,buf,len);
	}
    //printf("Write %d bytes to UE!", len);
    //for(i=0; i<16; i++)
    //  printf("0x%2X ", buf[i]);
    //printf("\n");
}

void clearport(int fd)
{
    tcflush(fd,TCIOFLUSH);
}

int FindDBVer(char *pBuff, int nLength)
{
    if (pBuff==NULL)
    {
        return 0;
    }

    //char szAPDBVer[9] = {0};
    //char szCPDBVer[9] = {0};
    char *pCurrent = pBuff;

    //printf("pBurr: 0x%X, nLength: %d\n", pBuff, nLength);
    while( (pCurrent+27) <= (pBuff+nLength) )
    {
        if ( (char)0x1B == *pCurrent && (char)0x00 == *(pCurrent+1) && (char)0x00 == *(pCurrent+2) && (char)0x00 == *(pCurrent+3) )
        {
            //printf("Found the PDU Head!\n");
            //printf("\npCurrent+8 == 0xFF: %d!", -1 == *(pCurrent+8));
            //printf("\npCurrent+8: 0x%X!", (char)*(pCurrent+8));
            //printf("\npCurrent+10 == 0x00: %d!", 0x00 == *(pCurrent+10));
            //printf("\npCurrent+10: %d!", *(pCurrent+10));
            if ( (char)0x01 == *(pCurrent+4) && (char)0xFF == *(pCurrent+8) && (char)0xFF == *(pCurrent+9) \
                    && ((char)0x00 == *(pCurrent+10)) && ((char)0x00 == *(pCurrent+11)) )
            {
                //printf("\nFound DB Ver\n");
                if( 0x00 == *(pCurrent+5) )
                {
                    //memcpy(szCPDBVer, pCurrent+18, 9);
                    g_SDLHeader.dwCPVersion = strtoul(pCurrent+18, NULL, 16);
                    printf("\nGot the CP DB Ver: 0x%X\n", g_SDLHeader.dwCPVersion);
		    return 1;
                }
                else if ( (char)0x80 == *(pCurrent+5) )
                {
                    //memcpy(szAPDBVer, pCurrent+18, 9);
                    g_SDLHeader.dwAPVersion = strtoul(pCurrent+18, NULL, 16);
                    //printf("\nGot the AP DB Ver: 0x%X\n", g_SDLHeader.dwAPVersion);
                }
                else
                {
                    //printf("\npCurrent+5: %d!", *(pCurrent+5));
                    printf("\nSAP is invalid\n");
                }

                pCurrent+=15;
            }
            else
            {
                //printf("\npCurrent+11: %d!\n", *(pCurrent+11));
            }
        }

        pCurrent++;
    }
	g_nFindDbVer++;
    //printf("pCurrent: 0x%X\n", pCurrent);
    return 0;
}

int readport(PUSB_HANDLE pUSB,unsigned char *buf,int maxwaittime)
{
    int len=0;
    int rc;
    int i;
    char progress[4];
    progress[0] = '\\';
    progress[1] = '|';
    progress[2] = '/';
    progress[3] = '-';

	if (!g_isTty)
	{
	    if( NULL == pUSB )
	    {
	        return -1;
	    }
	    rc=DiagDev_Read(pUSB,buf,MAX_TRANSFER, maxwaittime);
	} else
	{
		rc = read(g_ttyfd,buf,MAX_TRANSFER);
	}
    printf("%c Read %d bytes from UE                \r", progress[g_ProgIndex], rc);
    g_ProgIndex = ++g_ProgIndex>=4?0:g_ProgIndex;

    if(rc==-1)
    {
        g_nReadFailCount++;
        if(g_nReadFailCount>1000)
        {
            printf("Read fail more than %d times, send GetAPDBVer&GetCPDBVer to UE again!\n", g_nReadFailCount);

            //writeport(pUSB,ACATReady,16);
            //usleep(200000);
            writeport(pUSB,GetAPDBVer,16);
            usleep(10000);
            writeport(pUSB,GetCPDBVer,16);
            usleep(10000);
            g_nReadFailCount = 0;
        }
    }
    else
	g_nReadFailCount = 0; //count from 0 once read buf OK.
    return rc;
}

void CleanOldSdl(char *dir, int depth)
{
    DIR *dp;
    struct stat buf;
    struct dirent *entry;
    struct stat statbuf;
    long OldTime = 0;
    char FileName[256];

    if(g_uiFileIndex<=g_nFileMaxCount)
    {
        return;
    }

    if((dp = opendir(dir)) == NULL)
    {
        fprintf(stderr,"cannot open directory: %s\n", dir);
        return;
    }
    chdir(dir);
    while((entry = readdir(dp)) != NULL)
    {
        lstat(entry->d_name,&statbuf);
        if(S_ISDIR(statbuf.st_mode))
        {

            /*if(strcmp(".",entry->d_name) == 0 ||
                strcmp("..",entry->d_name) == 0)
                continue;
            printf("%*s%s/\n",depth,"",entry->d_name);

            printdir(entry->d_name,depth+4);*/
        }
        else
        {
            //printf("%s\n",entry->d_name);
            stat(entry->d_name, &buf);
            if(OldTime>buf.st_mtime || OldTime == 0)
            {
                OldTime = buf.st_mtime;
                strcpy(FileName, entry->d_name);
            }
        }

    }

    if(OldTime!=0)
    {
        remove(FileName);
        //printf("Deleted the oldest file %s\n",FileName);
    }

    chdir("..");
    closedir(dp);
}

/*FILE *CreateFile(const char * path,const char * mode)
{
    struct ffblk ff;
    struct stat buf;
    int done;
    int FileCount = 0;
    long OldTime = 0;
    char FileName[256];
    char FilePath[256];
    char *pDevName = NULL;

    pDevName = strrchr(g_szDevName, '/');
    pDevName++;
    strcpy(FilePath, pDevName);
    strcat(FilePath, "/*.sdl");

    printf("Directory listing of %s\n", FilePath);
    done = findfirst(FilePath, ff, 0);
    while (!done)
    {
        FileCount++;
        //strcpy(fileName[i], ff.ff_name);
        stat(ff.ff_name, &buf);
        printf(" %s\n", ff.ff_name);
        if(OldTime>buf.st_mtime)
        {
            OldTime = buf.st_mtime;
            strcpy(FileName, ff.ff_name);
        }
        done = findnext(ff);
    }
    if(FileCount>g_nFileMaxCount)
    {
        remove(FileName);
    }
    return fopen(path, mode);
}*/

int savelog(unsigned char *buf, int len)
{
    int i;
    time_t ltime;
    struct tm *currtime;
    char openmode[4] = {0};
    struct stat fileinfo;

    char *pHeader = (char *)&g_SDLHeader;
	char szLogPath[256];
	if (g_szFileDir[strlen(g_szFileDir)-1] == '/')
		g_szFileDir[strlen(g_szFileDir)-1] = 0;
	memcpy(szLogPath, g_szFileDir, sizeof(g_szFileDir));
#if 0
    char *pDevName = NULL;
    

    //printf("\nCurrent g_SDLHeader.dwAPVersion: 0x%X", g_SDLHeader.dwAPVersion);
    //printf("\nCurrent g_SDLHeader.dwCPVersion: 0x%X\n", g_SDLHeader.dwCPVersion);

    memset(szLogPath, 0, sizeof(szLogPath));
    pDevName = strrchr(g_szDevName, '/');
    pDevName++;
    sprintf(szLogPath, "%s_%s", pDevName, g_pSelectedUSB->iSerialNumber);
    if(access(szLogPath,0)==-1)// Check the folder exists
    {
        if (mkdir(szLogPath,0777))// Create the new folder
        {
            printf("creat folder %s\\ failed!!!\n", szLogPath);
            return 0;
        }
        else
        {
            printf("Create the folder %s\\.\n", szLogPath);
        }
    }
    else
        ;//printf("The folder %s\\ existed.\n", pDevName);
#endif


    if ( 0 == strlen(g_szLogFileName)  )
    {
        time(&ltime);

        g_SDLHeader.dwTime = (long)ltime;
        g_SDLHeader.dwSequenceNum = g_uiFileIndex;// File index, start from 0
		g_uiFileIndex++;
        currtime = localtime(&ltime);
        sprintf(g_szLogFileName, "%s//%d_%d_%d_%d_%d_%d.sdl", szLogPath, (currtime->tm_year+1900), (currtime->tm_mon+1), currtime->tm_mday, currtime->tm_hour, currtime->tm_min, currtime->tm_sec);
        //sprintf(openmode, "wb");
        g_hFile = fopen(g_szLogFileName, "wb");

        printf("Saving the log(%s) to %s\\ folder in current path!\n", g_szLogFileName,szLogPath);
	printf("1++g_SDLHeader.dwTime:0x%x,.dwCPVersion:0x%x,.dwSequenceNum:0x%x\n",g_SDLHeader.dwTime,g_SDLHeader.dwCPVersion,g_SDLHeader.dwSequenceNum);
        // Write the file header.
        if( fwrite(pHeader, 28, 1, g_hFile) != 1 )
        {
            printf("Write Header fail: create file.\n");
        }
		CleanOldSdl(szLogPath,0);
//        for(i=0; i<28; i++)
//            fputc(pHeader[i], g_hFile);
    }
    else
    {
        stat(g_szLogFileName, &fileinfo);
        if( (g_uiFileSize>0 && fileinfo.st_size > g_uiFileSize*1024*1024-len) || (fileinfo.st_size > FILE_SIZE*1024*1024-len) ) 
        {
            // Update the AP CP DB Version before close the file
            g_hFile = fopen(g_szLogFileName, "ab+");
            fseek(g_hFile, 0, SEEK_SET);
            if( fwrite(pHeader, 28, 1, g_hFile) != 1 )
            {
                printf("Write Header fail: file size is not enough.\n");
            }
//            for(i=0; i<28; i++)
//                fputc(pHeader[i], g_hFile);

            fclose(g_hFile);
            g_hFile = NULL;


            time(&ltime);

            g_SDLHeader.dwTime = (long)ltime;
            g_SDLHeader.dwSequenceNum = g_uiFileIndex;//�ļ���ţ���0��ʼ����
			g_uiFileIndex++;    // Increse the file index
            currtime = localtime(&ltime);
            sprintf(g_szLogFileName, "%s//%d_%d_%d_%d_%d_%d.sdl", szLogPath, currtime->tm_year+1900, currtime->tm_mon+1, currtime->tm_mday, currtime->tm_hour, currtime->tm_min, currtime->tm_sec);
//          sprintf(openmode, "wb");
            g_hFile = fopen(g_szLogFileName, "wb");
            // Write the file header.
            if( fwrite(pHeader, 28, 1, g_hFile) != 1 )
            {
                printf("Write Header fail: create a new file.\n");
            }
	    printf("++created new log file(%s)\n",g_szLogFileName);
//            for(i=0; i<28; i++)
//                fputc(pHeader[i], g_hFile);

            CleanOldSdl(szLogPath,0);
        }
        else
        {
            //sprintf(openmode, "ab+");
            g_hFile = fopen(g_szLogFileName, "ab+");
        }
    }

    // Write the data to current file.
    if( fwrite(buf, len, 1, g_hFile) != 1 )
    {
        printf("Write data fail.\n");
    }
//    for(i=0; i<len; i++)
//        fputc(buf[i], g_hFile);

    if(g_hFile != NULL)
    {
        fclose(g_hFile);
        g_hFile = NULL;
    }
    return 1;

}

int Connect(PUSB_HANDLE pUSB)
{
    int ret = 0;

    if((!g_isTty) && ( 0 == strlen(g_szDevSerNum) || !strcmp(g_szDevSerNum, pUSB->iSerialNumber) ) )
    {
        //Open Diag device
        if( DiagDev_OpenDev(pUSB) )
        {
			memcpy( g_szDevSerNum, pUSB->iSerialNumber, sizeof(g_szDevSerNum) );
            ret = 1;
        }
    }
	if (g_isTty)
	{
        int retry;
        for (retry = 0; retry < 30; retry++)
        {
            usleep(100*1000);
            if (access(g_szDevName, R_OK | W_OK))
            {
                //not connect
                retry = 0;
            }
        }
		g_ttyfd = openport(g_szDevName);
		if (g_ttyfd != -1)
		{
			ret = 1;
		}
	}
	if (1 == ret)
	{
		usleep(200);
            writeport(pUSB,ACATReady,16);
		usleep(200);
            writeport(pUSB,GetAPDBVer,16);
		usleep(300);
            writeport(pUSB,GetCPDBVer,16);
            usleep(100);
	}
    //Send the ACAT Ready to UE
    //writeport(g_hDevHandle,GetAPDBVer,16);
    //usleep(2000000);
    return ret;
}

int AutoReConnect(PUSB_HANDLE pUSB)
{
    int bConnect = 0;
    int nIndex = 0;
    USB_HANDLE hUSBArray[MAX_DEVNUM];
	if (!g_isTty)
    {
		DiagDev_CloseDev(pUSB);
	} else
	{
		if (g_ttyfd != -1)
			close(g_ttyfd);
	}
    while(!bConnect)
    {
        usleep(10000);
		if (!g_isTty)
		{
			if( DiagDev_FindAllSupportedDevices(hUSBArray) )
	        {
	            for(nIndex=0; nIndex<MAX_DEVNUM; nIndex++)
	            {
	                memset(g_pSelectedUSB, 0, sizeof(g_pSelectedUSB));
	                memcpy(g_pSelectedUSB->DevName, hUSBArray[nIndex].DevName, sizeof(g_pSelectedUSB->DevName));
	                memcpy(g_pSelectedUSB->iSerialNumber, hUSBArray[nIndex].iSerialNumber, sizeof(g_pSelectedUSB->iSerialNumber));

	                if( Connect( g_pSelectedUSB ) == 1)
	                {
	                    printf("Auto-reconnect device successfully.\n");
	                    bConnect = 1;
	                }
	            }
	        }
		} else
		{
			if (access(g_szDevName, R_OK | W_OK) == 0)
			{
				 if( Connect( g_pSelectedUSB ) == 1)
                {
                    printf("Auto-reconnect device successfully.\n");
		printf("2++g_isTty:%d, g_szDevName:%s ,g_nFileMaxCount:%d ,g_szFileDir:%s, g_uiFileSize:%d\n",g_isTty,g_szDevName,g_nFileMaxCount,g_szFileDir,g_uiFileSize);

                    bConnect = 1;
                }
			}
		}

    }
	if (bConnect)
	{
		g_nFindDbVer = 0;
	}
    return bConnect;
}

void ctrl_c_process(int signo)
{
    char *pHeader = (char *)&g_SDLHeader;
    int i = 0;

    // Update the file header before close the file
    if(0 != strlen(g_szLogFileName))
    {
        g_hFile = fopen(g_szLogFileName, "rb+");
        fseek(g_hFile, 0, SEEK_SET);
        if( fwrite(pHeader, sizeof(struct CSDLFileHeader), 1, g_hFile) != 1 )
        {
            printf("Write data fail: ctrl_c_process.\n");
        }
//        for(i=0; i<28; i++)
//            fputc(pHeader[i], g_hFile);
    }

    if(g_hFile != NULL)
    {
        fclose(g_hFile);
        g_hFile = NULL;
    }
    printf("\nExiting DiagSaver...\n");
    sleep(1);
    exit(1);
}

int main()
{
    int   fd,rc,i,ret,readlen;
    readlen = 0;
    unsigned char rbuf[MAX_TRANSFER] = {0};
    int nReadCount = 0;
    int nSentCount = 0;
    int nCPVerCmd = 0;

    //char *dev ="/dev/ttyACM0";    //Set the ZTE Diag device path

    // init the SDL file header
    g_SDLHeader.dwHeaderVersion = 0;
    g_SDLHeader.dwDataFormat = 1;//0x1
    g_SDLHeader.dwAPVersion = 0;//strtol(g_szAPDBVer, NULL, 16);
    g_SDLHeader.dwCPVersion = 0;//strtol(g_szCPDBVer, NULL, 16);
    g_SDLHeader.dwTime = 0;//Total seconds from 1970.1.1 0:0:0
    g_SDLHeader.dwCheckSum = 0;//0x0

    // Capture the Ctrl+C
    struct sigaction act;
    act.sa_handler = ctrl_c_process;
    act.sa_flags = 0;
    if( sigaction(SIGINT, &act, NULL) < 0 )
    {
        printf("Install Signal Action Error: %s \n", strerror(errno));
        return 0;
    }

    printf("========================================================\n               ASE DiagSaver v3.0.0.0\n========================================================\n");

    //============================= Non-Driver access test ================================
    int bAdd = 0;
    int bInputOK = 0;
    int nDevNameLen = 0;
    int nSelectedDev = -1;
    char szInput[8];
    char Refresh;
    int nIndex = 0;
    int flag_findDB = 0;
    USB_HANDLE hUSBArray[MAX_DEVNUM];

	while (1)
  	{
	  	printf("========================================================\n\
	       \rPlease input the communication number to select one method to capture\n\
	       0 Diag\n\
	       1 ttyUSB\n");
		printf(": ");
		int nLen = scanf("%s", szInput);
		if (nLen > 1)
			continue;
		if (szInput[0] == '0')
		{
			g_isTty = 0;
			break;
		} else if (szInput[0] == '1')
		{
			g_isTty = 1;
			break;
		} else
			continue;
	}
	printf("========================================================\n");
	if (!g_isTty)
    {
		g_pSelectedUSB = (USB_HANDLE *)calloc(1, sizeof(USB_HANDLE));
		while(!bInputOK)
	    {
	        printf("Found Diag Devices:\n\
	              \r  DevNum    Path                  iSerialNumber\n\
	              \r--------------------------------------------------------\n");
	        if( DiagDev_FindAllSupportedDevices(hUSBArray) )
	        {
	            for(nIndex=0; nIndex<MAX_DEVNUM; nIndex++)
	            {
	                if(0 != strlen(hUSBArray[nIndex].DevName) )
	                {
	                    printf("# Device %d: %s  %s\n", nIndex, hUSBArray[nIndex].DevName, hUSBArray[nIndex].iSerialNumber);
	                }
	            }
	            printf("--------------------------------------------------------\n\
	                   \rPlease input the device number to select one device to capture\n\
	                   \rOr input \"r\" to refresh device list\n\
	                   \r[Example: \"0\" means capture the log from device 0 ]\n");
	        }
	        else
	        {
	            printf("Never found any diag device, please input \"r\" to refrash!\n");
	        }

	        while(1)
	        {
	            printf(": ");
	            int nLen = scanf("%s", szInput);
	            if( 1 == nLen && ( 'r' == ( Refresh = tolower(szInput[0]) ) || ( szInput[0] < 0x35  && szInput[0] >= 0x30 ) ) )
	            {
	                //printf("Enter %s\n", szInput);
	                if ('r' == Refresh )
	                    break;
	                nSelectedDev = szInput[0] - 0x30;
	                sprintf( g_szDevName, "/Device%d", nSelectedDev);
	                memcpy(g_pSelectedUSB->DevName, hUSBArray[nSelectedDev].DevName, sizeof(g_pSelectedUSB->DevName));
	                memcpy(g_pSelectedUSB->iSerialNumber, hUSBArray[nSelectedDev].iSerialNumber, sizeof(g_pSelectedUSB->iSerialNumber));
	                bInputOK = 1;
	                break;
	            }
	            else
	            {
	                printf("Invalid enter, please retry!\n");
	                continue;
	            }
	        }

	    }
	}else 
	{
		while (1)
		{
			printf("Please input Device path [Example: /dev/ttyUSB0]\n: ");
			scanf("%s", g_szDevName);
			if (is_ttydevice(g_szDevName))
				break;
		}
	}
    
	printf("========================================================\n");
    printf("Please enter Max sdl file count[Example: 20]: \n");
    scanf("%d", &g_nFileMaxCount);
    printf("========================================================\n");
	while (1)
	{
	printf("Please enter the Dir of Log Files[Example: ./]: \n");
    scanf("%s", g_szFileDir);
	mkdir(g_szFileDir,0777);
	if (access(g_szFileDir, R_OK | W_OK) == 0)
		break;
	}
    printf("========================================================\n");
	while (1)
	{
		printf("Please enter the Log File Size MB, Not Bigger than %dM or Input 0 to Create a new Log File when UE reboot[Example: 20]: \n",FILE_SIZE);
	    scanf("%lu", &g_uiFileSize);
		if (g_uiFileSize <= FILE_SIZE)
			break;
	}



    //Open Diag device
    int bSuccess = Connect(g_pSelectedUSB);
    //int bSuccess = gDiagDev.OpenDev(g_pSelectedUSB);
    if (!bSuccess)
    {
        printf("Open the Diag Fail!\n");
        return 0;
    }

    printf("Sent CMD, receiving data. Press Ctrl+C to exit.\n");
    while(1)
    {
        rc=readport(g_pSelectedUSB,rbuf,3000);   //Read data, timeout is 500 ms
        if(rc>0)
        {
            //for(i=0;i<rc;i++)
            //  printf("%02x ",rbuf[i]);
            //printf("\n");
            //usleep(2000);
            savelog(rbuf, rc);

            nReadCount++;
            if (nReadCount>10 && nSentCount<10)
            {
                if(0 == nCPVerCmd)
                {
                    writeport(g_pSelectedUSB,GetCPDBVer,16);
                    nCPVerCmd = 1;
                }
                else
                {
                    writeport(g_pSelectedUSB,GetAPDBVer,16);
                    nCPVerCmd = 0;
                }
                nReadCount=0;
                nSentCount++;
            }
			if (g_nFindDbVer < MAX_FINDDBVER_NUM && flag_findDB ==0)
            FindDBVer((char *)rbuf, rc);

        }
        else if((g_isTty == 0 && errno != 110) || (g_isTty && access(g_szDevName, R_OK | W_OK) == -1))
        {
            //writeport(fd,wbuf,16);
            //printf("recv none, data length: %d Bytes, errno: %d\n", rc, errno);
            printf("recv none, data length: %d Bytes, errno %d: %s\n", rc, errno, strerror(errno));
            printf("Device disconnect, waiting for Diag device connect...\n");
            usleep(500);
			if (0 == g_uiFileSize)
			{
				//Create a New Log File When reboot
				memset(g_szLogFileName, 0, sizeof(g_szLogFileName));
			}
            AutoReConnect(g_pSelectedUSB);
        }
    }
	if (!g_isTty)
    {	
		DiagDev_CloseDev(g_pSelectedUSB);
		if (g_pSelectedUSB)
		{
		    free(g_pSelectedUSB);
		    g_pSelectedUSB = NULL;
		}
	} else
	{
		close(g_ttyfd);
		g_ttyfd = -1;
	}
}

