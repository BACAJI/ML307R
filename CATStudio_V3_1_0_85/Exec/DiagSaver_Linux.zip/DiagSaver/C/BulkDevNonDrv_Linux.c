/******************************************************************************
*(C) Copyright 2017 ASR Microelectronics (Shanghai) Co., Ltd.
* All Rights Reserved
******************************************************************************/

#include "BulkDevNonDrv_Linux.h"
#define MAX_RETRIES 5

#ifdef DBG_MODE
#define LOG_DBG(fmt, args...) printf(fmt, ##args)
#else
#define LOG_DBG(fmt, args...) do {}while(0);
#endif

DiagDev_CBulkDevNonDrv_Linux(void)
{
}

int DiagDev_check(void *_desc, int nLen, unsigned int type, int size)
{
	unsigned char *desc = (unsigned char *)_desc;

	if(nLen < size) return 0;
	if(desc[0] < size) return 0;
	if(desc[0] > nLen) return 0;
	if(desc[1] != type) return 0;

	return 1;
}

int DiagDev_badname(const char *name)
{
	while(*name)
	{
		if(!isdigit(*name++))
			return 1;
	}

	return 0;
}

int DiagDev_OpenDev(USB_HANDLE *usb)
{
	char DevDesc[1024];
	int bRet = 0;
	int hDevHandle = 0;
	int nLen = 0;
	int PipeIn = -1;
	int PipeOut = -1;
	int ifc_id = -1;

	if((hDevHandle = open(usb->DevName, O_RDWR)) >= 0)
	{
		printf("##########Open dev OK, %s\n", usb->DevName);
		nLen = read(hDevHandle, DevDesc, sizeof(DevDesc));
		if( DiagDev_GetPipeOfDev(DevDesc, nLen, &PipeIn, &PipeOut, &ifc_id) )
		{
			LOG_DBG("##########GetPipeOfWTPTP OK!\n");
			nLen = ioctl(hDevHandle, USBDEVFS_CLAIMINTERFACE, &ifc_id);
			if(nLen == 0)
			{
				LOG_DBG("##########Check ifc_id OK!\n");
				bRet = 1;
				usb->nPipeIn = PipeIn;
				usb->nPipeOut = PipeOut;
				usb->hDevHandle = hDevHandle;
				LOG_DBG("##########DevName is %s, PipeIn is %d, PipeOut is %d, hDevHandle is 0x%X\n",
					usb->DevName, usb->nPipeIn, usb->nPipeOut, usb->hDevHandle);
			}
			else
			{
			    printf("Check ifc_id fail! nLen: %d, errno(%d): %s\n", nLen, errno, strerror(errno));
				close(hDevHandle);
			}
		}
		else
			printf("GetPipeOfWTPTP fail!\n");
	}
	else
		printf("Open dev fail, hDevHandle=0x%X\n", hDevHandle);

	return bRet;
}

int DiagDev_CloseDev(USB_HANDLE *usb)
{
	int hDevHandle, ifc_id;

	hDevHandle = usb->hDevHandle;
	if(hDevHandle >= 0)
	{
		printf("########## release interface of %s\n", usb->DevName);
		ioctl(hDevHandle, USBDEVFS_RELEASEINTERFACE, &ifc_id);
		close(hDevHandle);
		printf("##########WTPTP dev: %s was closed!\n", usb->DevName);
		memset(usb->DevName, 0, 256);
		usb->hDevHandle = -1;
		usb->nPipeIn = -1;
		usb->nPipeOut = -1;

		return 1;
	}
	return 0;
}

int DiagDev_WaitDev()
{
	struct sockaddr_nl client;
	struct timeval tv;
	int CppLive, rcvlen, ret;
	fd_set fds;
	int buffersize = 2048;
		int nIndex;

	CppLive = socket(AF_NETLINK, SOCK_RAW, NETLINK_KOBJECT_UEVENT);
	memset(&client, 0, sizeof(client));
	client.nl_family = AF_NETLINK;
	client.nl_pid = getpid();
	client.nl_groups = 1;

	setsockopt(CppLive, SOL_SOCKET, SO_RCVBUF, &buffersize, sizeof(buffersize));
	bind(CppLive, (struct sockaddr*)&client, sizeof(client));

	char buff[2048] = {0};
	FD_ZERO(&fds);
	FD_SET(CppLive, &fds);
	tv.tv_sec = 0;
	tv.tv_usec = 100 * 1000;

	ret = select(CppLive+1, &fds, NULL, NULL, &tv);

	rcvlen = recv(CppLive, &buff, sizeof(buff), 0);
	if(rcvlen>0)
	{
		for(nIndex=0; nIndex<rcvlen; nIndex++)
		{
			if( '\0' == *(buff+nIndex) )
				buff[nIndex] = '\n';
		}
		printf("%s\n", buff);
	}
	close(CppLive);
	return 0;
}

int DiagDev_FindAllSupportedDevices(USB_HANDLE hUSBArray[])
{
	char *base = "/dev/bus/usb";
	char busname[64], devname[64];
	char *DevDesc = (char *)malloc(1024);
	char *OrigiPtr = DevDesc;
	DIR *busdir, *devdir;
	struct dirent *de;

	struct usb_device_descriptor *dev;
	struct usb_config_descriptor *cfg;
	struct usb_interface_descriptor *ifc;
	USB_IFC_INFO info;
	int loop;
	int bRet = 0;
	int hDevHandle = 0;
	int nDevNameLen = 0;
	int bAdd = 0;
	int nIndex = 0;
	int nBuffLen;
	struct usbdevfs_ctrltransfer ctrl;
	unsigned short buffer[128];
	unsigned short preCheck[128];
	int nPreCheckCount = 0;
	int result;
						
	memset(busname, 0, sizeof(busname));
	memset(devname, 0, sizeof(devname));
	memset(DevDesc, 0, sizeof(DevDesc));

	busdir = opendir(base);
	if(0 == busdir)
		return 0;

	while( de = readdir(busdir) )
	{
	
		if(DiagDev_badname(de->d_name))
			continue;
		else
			LOG_DBG("##########scan %s\n", de->d_name);

		sprintf(busname, "%s/%s", base, de->d_name);
		devdir = opendir(busname);
		if( 0 == devdir )
		   continue;

		while( de = readdir(devdir) )
		{
			if(DiagDev_badname(de->d_name))
				continue;

			nBuffLen = sprintf(devname, "%s/%s", busname, de->d_name);
	
			hDevHandle = open(devname, O_RDWR);
			if (hDevHandle < 0) {
				LOG_DBG("##########Opene %s failed: %d\n", devname, hDevHandle);
			} else if(hDevHandle >= 0) {
				LOG_DBG("##########Open %s pass\n", devname);
				DevDesc = OrigiPtr;
				nBuffLen = read(hDevHandle, DevDesc, 1024);

				if( !DiagDev_check( DevDesc, nBuffLen, USB_DT_DEVICE, USB_DT_DEVICE_SIZE ) ) {
					LOG_DBG("##########diag check USB_DT_DEVICE returns 0\n");
					continue;
				} else
					LOG_DBG("##########diag check USB_DT_DEVICE pass\n");
				dev = (struct usb_device_descriptor *)DevDesc;
				nBuffLen -= dev->bLength;
				DevDesc += dev->bLength;
				if( DiagDev_ChecHWIds(dev->idVendor, dev->idProduct, -1) )
				{
					if( !DiagDev_check( DevDesc, nBuffLen, USB_DT_CONFIG, USB_DT_CONFIG_SIZE ) ) {
						LOG_DBG("##########diag check USB_DT_CONFIG returns 0\n");
						continue;
					} else
						LOG_DBG("##########diag check USB_DT_CONFIG pass\n");

					info.serial_number[0] = 0;
					if(dev->iSerialNumber)
					{
						memset(buffer, 0, sizeof(buffer));
						memset(preCheck, 0, sizeof(preCheck));
						memset(&ctrl, 0, sizeof(ctrl));

						ctrl.bRequestType = USB_DIR_IN | USB_TYPE_STANDARD | USB_RECIP_DEVICE;
						ctrl.bRequest = USB_REQ_GET_DESCRIPTOR;
						ctrl.wValue = (USB_DT_STRING << 8) | 0; //dev->iSerialNumber;
						ctrl.wIndex = 0;			//__le16_to_cpu(0x409);
						ctrl.wLength = sizeof(preCheck);
						ctrl.data = preCheck;

						result = ioctl(hDevHandle, USBDEVFS_CONTROL, &ctrl);
						if(result>0)
						{
							int nLoop;
							nPreCheckCount = (result - 2) / 2;

							for( nLoop = 1; nLoop <= nPreCheckCount; nLoop++ )
							{
								memset(buffer, 0, sizeof(buffer));
								memset(&ctrl, 0, sizeof(ctrl));

								ctrl.bRequestType = USB_DIR_IN | USB_TYPE_STANDARD | USB_RECIP_DEVICE;
								ctrl.bRequest = USB_REQ_GET_DESCRIPTOR;
								ctrl.wValue = (USB_DT_STRING << 8) | dev->iSerialNumber;
								ctrl.wIndex = __le16_to_cpu(preCheck[nLoop]);
								ctrl.wLength = sizeof(buffer);
								ctrl.data = buffer;

								result = ioctl(hDevHandle, USBDEVFS_CONTROL, &ctrl);
								if(result>0)
								{
									int i = 0;
									result /= 2;
									for(i=1; i<result; i++)
									{
										info.serial_number[i-1] = buffer[i];
									}
									info.serial_number[i-1] = 0;
									LOG_DBG("##########iSerialNumber: %s\n", info.serial_number);
								}
								else
								{
									printf("Get iSerialNumber ioctl errno %d: %s\n", errno, strerror(errno));
								}
							}
						}
						else
						{
							printf("Pre-check ioctl errno %d: %s\n", errno, strerror(errno));
						}
					} else
						LOG_DBG("##########diag DiagDev_ChecHWIds failed\n");

					cfg = (struct usb_config_descriptor *)DevDesc;
					nBuffLen -= cfg->bLength;
					DevDesc += cfg->bLength;

					for(loop=0; loop<cfg->bNumInterfaces; )
					{
						if( !DiagDev_check( DevDesc, nBuffLen, USB_DT_INTERFACE, USB_DT_INTERFACE_SIZE ) )
						{
							nBuffLen -= DevDesc[0];
							DevDesc += DevDesc[0];
							LOG_DBG("##########check interface %d failed\n", loop);
							continue;
						}

						ifc = (struct usb_interface_descriptor *)DevDesc;
						nBuffLen -= ifc->bLength;
						DevDesc += ifc->bLength;

						if( DiagDev_ChecHWIds(dev->idVendor, dev->idProduct, ifc->bInterfaceNumber) )
						{
							USB_HANDLE usb;
							strcpy(usb.DevName, devname);
							if( 0 == strlen(info.serial_number) )
							{
								strcpy(usb.iSerialNumber, "None");
							}
							else
							{
								strcpy(usb.iSerialNumber, info.serial_number);
							}
							hUSBArray[nIndex] = usb;
							nIndex++;
							bRet = 1;
							LOG_DBG("########## Got one supported dev: VID: 0x%X, PID: 0x%X, MI:0x%X\n",
								dev->idVendor, dev->idProduct, ifc->bInterfaceNumber);
						}
						loop++;
					}
				}
				LOG_DBG("##########close handle\n");
				close(hDevHandle);
			} else
		  		LOG_DBG("########## open device failed\n");
		}
		closedir(devdir);
	}
	closedir(busdir);
	free(OrigiPtr);
	DevDesc = NULL;
	OrigiPtr = NULL;
	return bRet;
}

int DiagDev_ChecHWIds(long idVendor, long idProduct, int MI)
{
	int nIndex = 0;
	int bFound = 0;

	LOG_DBG("##########vid: 0x%lx, pid: 0x%lx, MI: %lx\n", idVendor, idProduct, MI);
	for(nIndex=0; 0x0!=HWIds_CurrentTable[nIndex][0]; nIndex++)
	{
		if( idVendor == HWIds_CurrentTable[nIndex][0] \
				&& idProduct == HWIds_CurrentTable[nIndex][1] \
				&& (-1 == MI || -1 == HWIds_CurrentTable[nIndex][2]
					|| MI == HWIds_CurrentTable[nIndex][2] ) )
		{
			bFound = 1;
			break;
		} else
	  		LOG_DBG("##########HWID table: 0x%x,  0x%x,  0x%x\n",
			HWIds_CurrentTable[nIndex][0],
			HWIds_CurrentTable[nIndex][1],
			HWIds_CurrentTable[nIndex][2]);
	}

	LOG_DBG("------check hw id return %d\n", bFound);
	return bFound;
}

int DiagDev_GetPipeOfDev(char *ptr, int len, int *ept_in_id, int *ept_out_id, int *ifc_id)
{
	struct usb_device_descriptor *dev;
	struct usb_config_descriptor *cfg;
	struct usb_interface_descriptor *ifc;
	struct usb_endpoint_descriptor *ept;
	int in, out;
	unsigned i;
	unsigned e;

	if(!DiagDev_check(ptr, len, USB_DT_DEVICE, USB_DT_DEVICE_SIZE))
		return 0;

	dev = (struct usb_device_descriptor *) ptr;
	len -= dev->bLength;
	ptr += dev->bLength;

	if(!DiagDev_check(ptr, len, USB_DT_CONFIG, USB_DT_CONFIG_SIZE))
		return 0;

	cfg = (struct usb_config_descriptor *) ptr;
	len -= cfg->bLength;
	ptr += cfg->bLength;

	for(i = 0; i < cfg->bNumInterfaces;)
	{
		if( !DiagDev_check( ptr, len, USB_DT_INTERFACE, USB_DT_INTERFACE_SIZE ) )
		{
			len -= *ptr;
			ptr += *ptr;
			continue;
		}

		i++;
		ifc = (struct usb_interface_descriptor *) ptr;
		len -= ifc->bLength;
		ptr += ifc->bLength;

		if( !DiagDev_ChecHWIds(dev->idVendor, dev->idProduct, ifc->bInterfaceNumber) )
			continue;

		in = -1;
		out = -1;

		for(e = 0; e < ifc->bNumEndpoints; e++)
		{
			if(!DiagDev_check(ptr, len, USB_DT_ENDPOINT, USB_DT_ENDPOINT_SIZE))
				return 0;

			ept = (struct usb_endpoint_descriptor *) ptr;
			len -= ept->bLength;
			ptr += ept->bLength;

			if((ept->bmAttributes & 0x03) != 0x02)
				continue;

			if(ept->bEndpointAddress & 0x80)
			{
				in = ept->bEndpointAddress;
			}
			else
			{
				out = ept->bEndpointAddress;
			}
		}

		*ept_in_id = in;
		*ept_out_id = out;
		*ifc_id = ifc->bInterfaceNumber;
		LOG_DBG("##########ept_in_id: %d, ept_out_id: %d, ifc_id: %d\n", *ept_in_id, *ept_out_id, *ifc_id);

		return 1;
	}
	return 0;
}
int DiagDev_Write(USB_HANDLE *h, const void *_data, int len)
{
	unsigned char *data = (unsigned char*) _data;
	unsigned count = 0;
	struct usbdevfs_bulktransfer bulk;
	int n;
	int xfer;

	if(h->nPipeOut == 0)
	{
		return -1;
	}

	if(len == 0)
	{
		bulk.ep = h->nPipeOut;
		bulk.len = 0;
		bulk.data = data;
		bulk.timeout = 0;

		n = ioctl(h->hDevHandle, USBDEVFS_BULK, &bulk);
		if(n != 0)
		{
			fprintf(stderr,"ERROR: n = %d, errno = %d (%s)\n",
					n, errno, strerror(errno));
			return -1;
		}
		return n;
	}

	while(len > 0)
	{
		xfer = len;
		bulk.ep = h->nPipeOut;
		bulk.len = xfer;
		bulk.data = data;
		bulk.timeout = 0;
		LOG_DBG("##########Try write %d data\n", xfer);
		n = ioctl(h->hDevHandle, USBDEVFS_BULK, &bulk);
		if(n != xfer)
		{
			printf("ERROR: n = %d, errno = %d (%s)\n",
				   n, errno, strerror(errno));
			return -1;
		}

		count += xfer;
		len -= xfer;
		data += xfer;
	}

	LOG_DBG("##########Wrote %d bytes\n", count);
	return count;
}

int DiagDev_Read(USB_HANDLE *h, void *_data, int len, int timeout)
{
	unsigned char *data = (unsigned char*) _data;
	unsigned count = 0;
	struct usbdevfs_bulktransfer bulk;
	int n, retry;

	if(h->nPipeIn == 0)
	{
		return -1;
	}

	while(len > 0)
	{
		int xfer = len;
		bulk.ep = h->nPipeIn;
		bulk.len = xfer;
		bulk.data = data;
		bulk.timeout = timeout;
		retry = 0;

		do
		{
			LOG_DBG("##########usb will read %d bytes, hDevHandle = %d, DevName: %s\n",
			xfer, h->hDevHandle, h->DevName);
			n = ioctl(h->hDevHandle, USBDEVFS_BULK, &bulk);
			LOG_DBG("##########usb read %d bytes, Retry %d \n", n, retry);

			if( n < 0 )
			{

				if ( ++retry > MAX_RETRIES )
				{
					LOG_DBG("##########ERROR: n = %d, errno = %d (%s)\n",n, errno, strerror(errno));
					return -1;
				}
				usleep(10000);
			}
		}
		while( n < 0 );

		count += n;
		len -= n;
		data += n;

		if(n < xfer)
		{
			break;
		}
	}

	return count;
}
