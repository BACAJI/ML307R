/******************************************************************************
*(C) Copyright 2017 ASR Microelectronics (Shanghai) Co., Ltd.
* All Rights Reserved
******************************************************************************/

#ifndef __BULKDEV_NONDRV_LINUX_H__
#define __BULKDEV_NONDRV_LINUX_H__
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <dirent.h>
#include <fcntl.h>
#include <errno.h>
#include <pthread.h>
#include <ctype.h>

#include <sys/socket.h>
#include <linux/netlink.h>
#include <linux/usbdevice_fs.h>
#include <linux/usbdevice_fs.h>
#include <linux/version.h>

#if LINUX_VERSION_CODE > KERNEL_VERSION(2, 6, 20)
#include <linux/usb/ch9.h>
#else
#include <linux/usb_ch9.h>
#endif

#include <asm/byteorder.h>

#define MAX_DEVNUM 10

static int HWIds_WTPTPTable[31][3] =
{
    {0x0, 0x0, 0x0}
};

static int HWIds_USBDiagTable[][3] =
{
    {0x1286, 0x4E28, 4},
    {0x2ecc, 0x3010, 4},
    {0x2ecc, 0x3011, 2},
    {0x19d2, 0x1489, 4},
    {0x19d2, 0x1490, 2},
    {0x0, 0x0, 0x0}
};


static int (*HWIds_CurrentTable)[3] = HWIds_USBDiagTable;

typedef struct _USB_HANDLE
{
    char DevName[256];
    char iSerialNumber[256];
    int hDevHandle;
    int nPipeIn;
    int nPipeOut;
} USB_HANDLE, *PUSB_HANDLE;

typedef struct _USB_IFC_INFO
{
    unsigned short dev_vendor;
    unsigned short dev_product;

    unsigned char dev_class;
    unsigned char dev_subclass;
    unsigned char dev_protocol;

    unsigned char ifc_class;
    unsigned char ifc_subclass;
    unsigned char ifc_protocol;

    unsigned char has_bulk_in;
    unsigned char has_bulk_out;

    unsigned char writable;

    char serial_number[256];
} USB_IFC_INFO, *PUSB_IFC_INFO;

int DiagDev_OpenDev(USB_HANDLE *usb);
int DiagDev_CloseDev(USB_HANDLE *usb);
int DiagDev_Write(USB_HANDLE *h, const void *_data, int nLen);
int DiagDev_Read(USB_HANDLE *h, void *_data, int nLen, int timeout);
int DiagDev_CheckDevForNetLink(USB_HANDLE *usb, const char *NetLinkBuff, int nBuffLen, int *bAdd);
int DiagDev_WaitDev();
int DiagDev_FindAllSupportedDevices(USB_HANDLE hUSBArray[]);
#endif
